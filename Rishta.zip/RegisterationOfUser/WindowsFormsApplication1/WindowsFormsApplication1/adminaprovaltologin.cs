﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class adminaprovaltologin : Form
    {
        public adminaprovaltologin()
        {
            InitializeComponent();
        }

        private void adminaprovaltologin_Load(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            regreq r = new regreq();
            this.Hide();
            r.Show();
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            paid p = new paid();
            this.Hide();
            p.Show();
        }
    }
}
