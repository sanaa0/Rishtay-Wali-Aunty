﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Data;


namespace serveraunty
{
    public class AUNTY
    {


        //private string account;
        private string code;
        private string username;

        public string Username
        {
            get
            {
                return username;
            }

            set
            {
                username = value;
            }
        }


       // public string Account
        //{
           // get
            //{
              //  return account;
            //}

//            set
  //          {
    //            account = value;
      //      }
        //}



        public string Code
        {
            get
            {
                return code;
            }

            set
            {
                code = value;
            }
        }


        public static void getpayment(int number) { }
    }
}
