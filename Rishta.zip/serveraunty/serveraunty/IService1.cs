﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace serveraunty
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IService1
    {
        [OperationContract]
        void addper(RISHTA r);
        [OperationContract]
        void addpes(RISHTA r);
        [OperationContract]
        void addpe(RISHTA r);

        [OperationContract]
        List<RISHTA> paysender();
        [OperationContract]
        List<RISHTA> payreceiver();
        [OperationContract]
        List<RISHTA> payreq();

        [OperationContract]
        List<RISHTA> Allrishtay();

        [OperationContract]
        void fromtobetodone(List<RISHTA> roo);

        [OperationContract]
        RISHTA getr(string name);

        [OperationContract]
         List<RISHTA> Ddlj();
        [OperationContract]
         List<RISHTA> getlist();
        [OperationContract]
        string GetData(int value);

        [OperationContract]
        CompositeType GetDataUsingDataContract(CompositeType composite);


        [OperationContract] // registration of user basically
        void addrishtaof(RISHTA r);


        [OperationContract]
        void deleterishtaof(RISHTA r);

        [OperationContract]   //login of user
        bool loginof(string email, string password);



        [OperationContract]
        void editprofileof();


        [OperationContract]
        void approverishtaof(RISHTA r);



        [OperationContract]
        void getpaymentof(int number);

        [OperationContract]
        RISHTA seekofrishta(string name);

        [OperationContract]
        void allowofdetails();


        [OperationContract]   //register of admin
        void regofadmin(AUNTY a);

        [OperationContract]   // login of admin
        bool loginofadmin(AUNTY b);

        [OperationContract]
        List<RISHTA> getrishta(string ctgry, string choice, RISHTA curr);

        [OperationContract]
        void addrishtatobeapprovedof(RISHTA r);

        [OperationContract]    // add in the sentlist of current user that he has sent a request to this RISHTA
        void addInSent(RISHTA r1, RISHTA r2);

        [OperationContract]   // recieves Rishtas in list who has sent user requests
        void addInRecieved(RISHTA r1, RISHTA r2);

        [OperationContract]   // those rishtas whose sent requests has been approved
        void addInApproved(RISHTA r1, RISHTA r2);

        [OperationContract]
        void deleteRishta(RISHTA r);

        [OperationContract]    // like delete request to contact from a Rishta
        void removeFromSent(RISHTA r1, RISHTA r2);

        [OperationContract]   // does the same as above from other user
        void removeFromRecieved(RISHTA r1, RISHTA r2);


        [OperationContract]     // it has all the requests which are sent by users
        List<RISHTA> AllSender();

        [OperationContract]
        void addInAllSenders(RISHTA r);
    }


    // Use a data contract as illustrated in the sample below to add composite types to service operations.
    [DataContract]
    public class CompositeType
    {
        bool boolValue = true;
        string stringValue = "Hello ";

        [DataMember]
        public bool BoolValue
        {
            get { return boolValue; }
            set { boolValue = value; }
        }

        [DataMember]
        public string StringValue
        {
            get { return stringValue; }
            set { stringValue = value; }
        }
    }
}
