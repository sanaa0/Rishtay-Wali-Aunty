﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Data;



namespace serveraunty
{
    public class RISHTAlist
    {
        public static List<RISHTA> rishtay = new List<RISHTA>();

        private static List<RISHTA> allsenders = new List<RISHTA>();
        public static List<RISHTA> rishtaytobeapproved = new List<RISHTA>();
        public static List<RISHTA> paymentlist = new List<RISHTA>();
        public static List<RISHTA> paymentsender = new List<RISHTA>();
        public static List<RISHTA> paymentreceiver = new List<RISHTA>();
        

        public static void Fromtobetodone(List<RISHTA> roo)

        {
            //bool valid = false;
            foreach (RISHTA r in roo)
            {
                    if (r.statuss == true)
                    {
                        rishtay.Add(r);
              //          valid = true;
                    }
            }
            //return valid;
        }

        public static RISHTA getr(string name)
        {
            foreach (RISHTA r in rishtaytobeapproved )
            {
                if (r.Name == name)
                {
                    return r;
                }
            }
            return null ;
        }

        public static List<RISHTA> Rishtay
        {
            get
            {
                return rishtay;
            }

            set
            {
                rishtay = value;
            }
        }

        public static List<RISHTA> Paymentlist
        {
            get
            {
                return paymentlist;
            }

            set
            {
                paymentlist = value;
            }
        }


        public static List<RISHTA> Paymentsender
        {
            get
            {
                return paymentsender;
            }

            set
            {
                paymentsender = value;
            }
        }


        public static List<RISHTA> Paymentreceiver
        {
            get
            {
                return paymentreceiver;
            }

            set
            {
                paymentreceiver = value;
            }
        }



        public static List<RISHTA> Rishtaytobeapproved
        {
            get
            {
                return rishtaytobeapproved;
            }

            set
            {
                rishtaytobeapproved = value;
            }
        }

        public static List<RISHTA> Allsenders
        {
            get
            {
                return allsenders;
            }

            set
            {
                allsenders = value;
            }
        }

        public static void addrishtatobeapproved(RISHTA r)
        {
            Rishtaytobeapproved.Add(r);
        }


        public static void addrishta(RISHTA r)
        {
            Rishtay.Add(r);
        }
        public static void deleterishta(RISHTA r) { }

        internal static void Add(AUNTY a)
        {
          
        }
        

        
        public static bool login(string email, string password)
        {
            bool t = false;
            foreach (RISHTA r in RISHTAlist.Rishtay)
            {
                if (r.Email == email && r.Password == password)
                {
                    t = true;
                }

            }
            return t;

        }
        public static void approverishta(RISHTA r) { }
        public static void editprofile() { }

        public List<RISHTA> getRishta(string ctgry, string choice, RISHTA curr)
        {
            List<RISHTA> searchResults = new List<RISHTA>();
            foreach (RISHTA r in RISHTAlist.Rishtay)
            {
                bool found = false;
                if (r.Name != curr.Name)
                {
                    if (ctgry == "Name" && r.Name == choice)
                        found = true;
                    else if (ctgry == "Age" && r.Age == choice)
                        found = true;
                    else if (ctgry == "Cast" && r.Cast == choice)
                        found = true;
                    else if (ctgry == "City" && r.City == choice)
                        found = true;
                    else if (ctgry == "Gender" && r.Gender == choice)
                        found = true;
                    else if (ctgry == "Height" && r.Height == choice)
                        found = true;
                    else if (ctgry == "Income" && r.Income == choice)
                        found = true;
                    else if (ctgry == "Profession" && r.Profession == choice)
                        found = true;
                    else if (ctgry == "Religion" && r.Religion == choice)
                        found = true;

                    if (found)
                    {
                        searchResults.Add(r);
                    }
                }
            }
            return searchResults;
        }

        public static RISHTA seekrishta(string name)
        {
            foreach (RISHTA r in RISHTAlist.Rishtay)
            {
                if (r.Name == name)
                {
                    return r;
                }
            }
            return null; ;
        }

    }
    
}
