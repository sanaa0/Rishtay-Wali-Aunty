﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Resources;
using serveraunty;

namespace serveraunty
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {

        public List<RISHTA> paysender()
        {
            return RISHTAlist.Paymentsender;
        }

        public List<RISHTA> payreceiver()
        {
            return RISHTAlist.Paymentreceiver;
        }
        public List<RISHTA> payreq()
        {
            return RISHTAlist.Paymentlist;
        }


        public void addper(RISHTA r)
        {
            RISHTAlist.Paymentreceiver.Add(r);
        }

        public void addpes(RISHTA r)
        {
            RISHTAlist.Paymentsender.Add(r);
        }


        public void addpe(RISHTA r)
        {
            RISHTAlist.Paymentlist.Add(r);
        }



        public List<RISHTA> Allrishtay()
        {
            return RISHTAlist.Rishtay;
        }

        public void fromtobetodone(List<RISHTA> roo)
        {


             RISHTAlist.Fromtobetodone(roo);
            
        }
        public RISHTA getr(string name)
        {
            return RISHTAlist.getr(name);
        }
        public void regofadmin(AUNTY a)
        {
            auntydl.regadmin(a);
        }
        
        public bool loginofadmin(AUNTY b)
        {
            bool t = auntydl.loginadmin(b);
            return t;
        }

        public void allowofdetails()
        {
            RISHTA.allowdetails();
        }

       
        public void approverishtaof(RISHTA r)
        {
            RISHTAlist.approverishta(r);
        }

        public void getpaymentof(int number)
        {
            AUNTY.getpayment(number);
        }

        public void deleterishtaof(RISHTA r)
        {
            RISHTAlist.deleterishta(r);
        }

        public RISHTA seekofrishta(string name)
        {
            return RISHTAlist.seekrishta(name);
        }


        public List<RISHTA> Ddlj()
        {
            return RISHTAlist.rishtaytobeapproved;
        }
        public bool loginof(string email, string password)
        {
            bool t = RISHTAlist.login(email, password);
            return t;
        }

        public  void addrishtatobeapprovedof(RISHTA r)
        {
            RISHTAlist.addrishtatobeapproved(r);
        }

        public void editprofileof()
        {
            RISHTAlist.editprofile();

        }

        public void addrishtaof(RISHTA r)
        {
            RISHTAlist.addrishta(r);
        }

        public string GetData(int value)
        {
            return string.Format("You entered: {0}", value);
        }

        public CompositeType GetDataUsingDataContract(CompositeType composite)
        {
            if (composite == null)
            {
                throw new ArgumentNullException("composite");
            }
            if (composite.BoolValue)
            {
                composite.StringValue += "Suffix";
            }
            return composite;
        }

        public List<RISHTA> getrishta(string ctgry, string choice, RISHTA curr)
        {
            RISHTAlist R = new RISHTAlist();
            List<RISHTA> s = R.getRishta(ctgry, choice, curr);
            return s;
        }

        public List<RISHTA> getlist()
        {
            return RISHTAlist.Rishtaytobeapproved;
        }

        public void addInSent(RISHTA r1, RISHTA r2)
        {
            r1.Sentlist.Add(r2);
        }

        public void removeFromSent(RISHTA r1, RISHTA r2)
        {
            r1.Sentlist.Remove(r2);
        }

        public void addInRecieved(RISHTA r1, RISHTA r2)
        {
            r1.Receivedlist.Add(r2);
        }

        public void removeFromRecieved(RISHTA r1, RISHTA r2)
        {
            r1.Receivedlist.Remove(r2);
        }

        public void addInApproved(RISHTA r1, RISHTA r2)
        {
            r1.Approvedlist.Add(r2);
            r2.Approvedlist.Add(r1);
        }

        public void deleteRishta(RISHTA r)
        {
            RISHTAlist.Rishtay.Remove(r);
        }


        public List<RISHTA> AllSender()
        {
            return RISHTAlist.Allsenders;
        }

        public void addInAllSenders(RISHTA r)
        {
            RISHTAlist.Allsenders.Add(r);
        }

    }
}
