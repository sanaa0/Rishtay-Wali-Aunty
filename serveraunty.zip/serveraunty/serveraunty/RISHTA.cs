﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace serveraunty
{
    
    public class RISHTA
    {
        private string email;
        private string password;
        private string name;
        private string fatherName;
        private string gender;
        private string age;
        private string city;
        private string religion;
        private string cast;
        private string income;
        private string height;
        private string contact;
        private string profession;
        private Boolean allowedcontact;
        private Boolean rishtacame;
        private Boolean status = false;
        public Boolean statuss;   //sana made it for her own use
        private Boolean sitatuss = false;
        public static List<NOTIFICATION> notis = new List<NOTIFICATION>();
        public List<RISHTA> sentlist = new List<RISHTA>();
        public List<RISHTA> approvedlist = new List<RISHTA>();
        public List<RISHTA> receivedlist = new List<RISHTA>();

        /* public RISHTA (string nname, string aage)
         {
             name = nname;
             age = aage;

         }*/
        public RISHTA()
        {
           

        }

        public static void allowdetails()  // all of these have paid
        {
            foreach (RISHTA r in RISHTAlist.Paymentlist)
            {
                r.Sitatuss = true;
            }
        }

     
        public string Email
        {
            get
            {
                return email;
            }

            set
            {
                email = value;
            }
        }

        public string Password
        {
            get
            {
                return password;
            }

            set
            {
                password = value;
            }
        }

        public string Name
        {
            get
            {
                return name;
            }

            set
            {
                name = value;
            }
        }

        public string FatherName
        {
            get
            {
                return fatherName;
            }

            set
            {
                fatherName = value;
            }
        }

        public string Gender
        {
            get
            {
                return gender;
            }

            set
            {
                gender = value;
            }
        }

        public string Age
        {
            get
            {
                return age;
            }

            set
            {
                age = value;
            }
        }

        public string City
        {
            get
            {
                return city;
            }

            set
            {
                city = value;
            }
        }

        public string Religion
        {
            get
            {
                return religion;
            }

            set
            {
                religion = value;
            }
        }

        public
            string Cast
        {
            get
            {
                return cast;
            }

            set
            {
                cast = value;
            }
        }

        public string Income
        {
            get
            {
                return income;
            }

            set
            {
                income = value;
            }
        }

        public string Height
        {
            get
            {
                return height;
            }

            set
            {
                height = value;
            }
        }

        public string Contact
        {
            get
            {
                return contact;
            }

            set
            {
                contact = value;
            }
        }

        public string Profession
        {
            get
            {
                return profession;
            }

            set
            {
                profession = value;
            }
        }

        public bool Allowedcontact
        {
            get
            {
                return allowedcontact;
            }

            set
            {
                allowedcontact = value;
            }
        }

        public bool Rishtacame
        {
            get
            {
                return rishtacame;
            }

            set
            {
                rishtacame = value;
            }
        }

        public static object This { get; private set; }

        public bool Status
        {
            get
            {
                return status;
            }

            set
            {
                status = value;
            }
        }

        public bool Sitatuss
        {
            get
            {
                return sitatuss;
            }

            set
            {
                sitatuss = value;
            }
        }

        public bool Statuss
        {
            get
            {
                return statuss;
            }

            set
            {
                statuss = value;
            }
        }
    }
}
