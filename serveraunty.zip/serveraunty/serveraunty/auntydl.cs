﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace serveraunty
{
    public class auntydl
    {
        private static int i = 0;
        private static List<AUNTY> aunties = new List<AUNTY>();

        public static void regadmin(AUNTY a)

        {

            if (auntydl.I == 0)
            {
                a.Code = "5410";
                auntydl.I = auntydl.I + 1;
                RISHTAlist.Add(a);
            }

            if (auntydl.I == 1)
            {
                a.Code = "6789";
                auntydl.I = auntydl.I + 1;
                RISHTAlist.Add(a);
            }

            if (auntydl.I == 2)
            {
                a.Code = "987654321";
                auntydl.I = auntydl.I + 1;
                RISHTAlist.Add(a);
            }
            if (auntydl.I >= 3)
            {
            }


        }


        public static bool loginadmin(AUNTY b)
        {
            bool is_valid = false;
            foreach (AUNTY a in Aunties)
            {
                if (a.Code == b.Code && a.Username == b.Username)
                {
                    is_valid = true;
                }

            }
            return is_valid;
        }

        public static int I
        {
            get
            {
                return i;
            }

            set
            {
                i = value;
            }
        }

        public static List<AUNTY> Aunties
        {
            get
            {
                return aunties;
            }

            set
            {
                aunties = value;
            }
        }
    }
}